Activation:
1) Copy the Keygen (32 bits or 64 bits) to C:\
2) Open Wolfram Mathematica, choose "Other Ways to Activate", "Manual Activation"
3) Open CMD (As Admin) and type: cd C:\ 
4) Then type mma11_2_keygen_64.exe (I will be like this: C:\mma11_2_keygen_64.exe)
5) Type your MathID in the CMD and Generate your License
6) Paste in Wolfram Activation and Enjoy :) !!!!
=================
www.downloadly.ir